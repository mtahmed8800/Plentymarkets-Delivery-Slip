# Generiertes Plugin 
[Weitere Informationen](https://developers.plentymarkets.com/marketplace/plugin-requirements#marketplace-user-guide)